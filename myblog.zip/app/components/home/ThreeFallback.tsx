import { loadingBox } from "./ThreeFallback.css";

export default function ThreeFallback() {
  return <div className={loadingBox}></div>;
}
