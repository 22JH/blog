"use client";
import Write from "../../write/page";

export default function Update() {
  return <Write />;
}
