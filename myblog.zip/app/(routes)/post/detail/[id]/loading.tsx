import PostDetailSkeleton from "@/app/components/post/detail/skeleton/PostDetailSkeleton";

export default function loading() {
  return <PostDetailSkeleton />;
}
