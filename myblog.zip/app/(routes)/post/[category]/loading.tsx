import PostListSkeleton from "@/app/components/post/list/skeleton/PostListSkeleton";

export default function loading() {
  return <PostListSkeleton />;
}
