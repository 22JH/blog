import GuestBookSkeleton from "@/app/components/guestBook/skeleton/GuestBookSkeleton";

export default function loading() {
  return <GuestBookSkeleton />;
}
