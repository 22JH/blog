export interface GusetBookType {
  _id?: string;
  text: string;
  name: string;
  thumbnail: string;
  createdAt?: string;
}
