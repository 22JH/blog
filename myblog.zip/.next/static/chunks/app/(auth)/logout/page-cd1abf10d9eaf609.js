(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[66],{11045:function(e,n,r){Promise.resolve().then(r.bind(r,13688))},13688:function(e,n,r){"use strict";r.r(n),r.d(n,{default:function(){return LoginBtn}});var t=r(57437),o=r(82749);function LoginBtn(){return(0,t.jsx)("button",{onClick:()=>{(0,o.signOut)()},children:"로그아웃"})}},30622:function(e,n,r){"use strict";/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var t=r(2265),o=Symbol.for("react.element"),u=Symbol.for("react.fragment"),f=Object.prototype.hasOwnProperty,i=t.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,s={key:!0,ref:!0,__self:!0,__source:!0};function q(e,n,r){var t,u={},c=null,_=null;for(t in void 0!==r&&(c=""+r),void 0!==n.key&&(c=""+n.key),void 0!==n.ref&&(_=n.ref),n)f.call(n,t)&&!s.hasOwnProperty(t)&&(u[t]=n[t]);if(e&&e.defaultProps)for(t in n=e.defaultProps)void 0===u[t]&&(u[t]=n[t]);return{$$typeof:o,type:e,key:c,ref:_,props:u,_owner:i.current}}n.Fragment=u,n.jsx=q,n.jsxs=q},57437:function(e,n,r){"use strict";e.exports=r(30622)}},function(e){e.O(0,[749,971,864,744],function(){return e(e.s=11045)}),_N_E=e.O()}]);